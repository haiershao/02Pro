//
//  main.m
//  jindouyun
//
//  Created by jiyi on 2017/8/3.
//  Copyright © 2017年 lh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
