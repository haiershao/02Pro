//
//  JDYNavView.m
//  jindouyun
//
//  Created by jiyi on 2017/8/4.
//  Copyright © 2017年 lh. All rights reserved.
//

#import "JDYNavView.h"

@implementation JDYNavView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
